/* jshint node: true */

module.exports = function(deployTarget) {
  return {
    pagefront: {
      app: 'rarwe',
      key: process.env.PAGEFRONT_KEY
    }
  };
};
